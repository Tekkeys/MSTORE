<?php 

$db = mysqli_connect("localhost","root","","ecom-store");

?>