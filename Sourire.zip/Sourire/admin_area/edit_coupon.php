<?php 

    if(!isset($_SESSION['admin_email'])){
        
        echo "<script>window.open('login.php','_self')</script>";
        
    }else{

?>

<?php 

if(isset($_GET['edit_coupon'])){
        
        $edit_id = $_GET['edit_coupon'];
        
        $get_coupon = "SELECT * FROM `coupons` WHERE coupon_id='$edit_id'";
        
        $run_edit = mysqli_query($db,$get_coupon);
        
        $row_edit = mysqli_fetch_array($run_edit);
        
        $coupon_id = $row_edit['coupon_id'];
       
        $coupon_title = $row_edit['coupon_title'];
            
        $coupon_price = $row_edit['coupon_price'];

        $coupon_code = $row_edit['coupon_code'];
        
        $coupon_limit = $row_edit['coupon_limit'];
        
        $coupon_used = $row_edit['coupon_used'];

        $prod_id = $row_edit['product_id'];

        $get_products = "SELECT * FROM `products` WHERE product_id='$prod_id'";

        $run_products = mysqli_query($db,$get_products);

        $row_products = mysqli_fetch_array($run_products);

        $product_id = $row_products['product_id'];

        $product_title = $row_products['product_title'];
   
    }

 ?>

<div class="row"><!-- row Begin -->
    
    <div class="col-lg-12"><!-- col-lg-12 Begin -->
        
        <ol class="breadcrumb"><!-- breadcrumb Begin -->
            
            <li class="active"><!-- active Begin -->
                
                <i class="fa fa-dashboard"></i> Dashboard / Edit Coupons
                
            </li><!-- active Finish -->
            
        </ol><!-- breadcrumb Finish -->
        
    </div><!-- col-lg-12 Finish -->
    
</div><!-- row Finish -->
       
<div class="row"><!-- row Begin -->
    
    <div class="col-lg-12"><!-- col-lg-12 Begin -->
        
        <div class="panel panel-default"><!-- panel panel-default Begin -->
            
           <div class="panel-heading"><!-- panel-heading Begin -->
               
               <h3 class="panel-title"><!-- panel-title Begin -->
                   
                   <i class="fa fa-money fa-fw"></i> Edit Coupon 
                   
               </h3><!-- panel-title Finish -->
               
           </div> <!-- panel-heading Finish -->
           
           <div class="panel-body"><!-- panel-body Begin -->
               
               <form method="post" class="form-horizontal"><!-- form-horizontal Begin -->
                   
                   <div class="form-group"><!-- form-group Begin -->
                       
                      <label class="col-md-3 control-label"> Coupon Title </label> 
                      
                      <div class="col-md-6"><!-- col-md-6 Begin -->
                          
                          <input value="<?php echo $coupon_title; ?>" name="coupon_title" type="text" class="form-control" required>
                          
                      </div><!-- col-md-6 Finish -->
                       
                   </div><!-- form-group Finish -->

                   <div class="form-group"><!-- form-group Begin -->
                       
                      <label class="col-md-3 control-label"> Coupon Price </label> 
                      
                      <div class="col-md-6"><!-- col-md-6 Begin -->
                          
                          <input value="<?php echo $coupon_price; ?>" name="coupon_price" type="text" class="form-control" required>
                          
                      </div><!-- col-md-6 Finish -->
                       
                   </div><!-- form-group Finish -->
                   
                   <div class="form-group"><!-- form-group Begin -->
                       
                      <label class="col-md-3 control-label"> Coupon Code </label> 
                      
                      <div class="col-md-6"><!-- col-md-6 Begin -->
                          
                          <input value="<?php echo $coupon_code; ?>" name="coupon_code" type="text" class="form-control" required>
                          
                      </div><!-- col-md-6 Finish -->
                       
                   </div><!-- form-group Finish -->
                   
                   <div class="form-group"><!-- form-group Begin -->
                       
                      <label class="col-md-3 control-label"> Coupon Limit </label> 
                      
                      <div class="col-md-6"><!-- col-md-6 Begin -->
                          
                          <input name="coupon_limit" type="number" class="form-control" value="<?php echo $coupon_limit; ?>">
                          
                      </div><!-- col-md-6 Finish -->
                       
                   </div><!-- form-group Finish -->

                   <div class="form-group"><!-- form-group Begin -->
                       
                      <label class="col-md-3 control-label"> Select Product </label> 
                      
                      <div class="col-md-6"><!-- col-md-6 Begin -->
                          
                          <select name="product_id" class="form-control" required>
                            
                            <option value="<?php echo $product_id; ?>"><?php echo $product_title; ?></option>

                            <?php 
                              
                              $get_product = "SELECT * FROM `products`";
                              $run_product = mysqli_query($db,$get_product);
                              
                              while ($row_product=mysqli_fetch_array($run_product)){
                                  
                                  $product_id = $row_product['product_id'];
                                  $product_title = $row_product['product_title'];
                                  
                                  echo "
                                  
                                  <option value='$product_id'> $product_title </option>
                                  
                                  ";
                                  
                              }
                              
                              ?>

                          </select>
                          
                      </div><!-- col-md-6 Finish -->
                       
                   </div><!-- form-group Finish -->
                   
                   <div class="form-group"><!-- form-group Begin -->
                       
                      <label class="col-md-3 control-label"></label> 
                      
                      <div class="col-md-6"><!-- col-md-6 Begin -->
                          
                          <input name="update" value="Edit Coupon" type="submit" class="btn btn-primary form-control">
                          
                      </div><!-- col-md-6 Finish -->
                       
                   </div><!-- form-group Finish -->
                   
               </form><!-- form-horizontal Finish -->
               
           </div><!-- panel-body Finish -->
            
        </div><!-- canel panel-default Finish -->
        
    </div><!-- col-lg-12 Finish -->
    
</div><!-- row Finish -->
   
  <script src="https://cdn.tiny.cloud/1/juufwowd49m6k96sn9d4uq08fhaycpw7q2uz9hiwn55dv9qf/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
  <script>tinymce.init({selector:'textarea'});</script>
</body>
</html>


<?php 

if(isset($_POST['update'])){
    
    $coupon_title = $_POST['coupon_title'];
    $coupon_price = $_POST['coupon_price'];
    $coupon_code = $_POST['coupon_code'];
    $coupon_limit = $_POST['coupon_limit'];
    $product_id = $_POST['product_id'];

    $update_coupon = "UPDATE `coupons` SET product_id='$product_id',coupon_title='$coupon_title',coupon_price='$coupon_price',coupon_code='$coupon_code',coupon_limit='$coupon_limit',coupon_used='$coupon_used' WHERE coupon_id='$coupon_id'";
        
        $run_coupon = mysqli_query($db,$update_coupon);
        
        if($run_coupon){
            
        echo "<script>alert('Your Coupon has been updated Successfully')</script>"; 
            
        echo "<script>window.open('index.php?view_coupons','_self')</script>"; 
            
        }
   
}

?>

<?php } ?>