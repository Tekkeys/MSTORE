<?php

$db = mysql_connect("localhost","root","","ecom-store");

?>