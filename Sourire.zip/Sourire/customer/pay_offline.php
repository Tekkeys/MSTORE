<center><!--  center Begin  -->
    
    <h1> Pay Offline Using Method </h1>
    
    <p class="text-muted">
        
        If you have any questions, feel free to <a href="../contact.php">Contact Us</a>. 
        Our Customer Service work <strong>24/7</strong>

    
    <table class="table table-bordered table-hover table-striped"><!--  table table-bordered table-hover Begin  -->
        
        <thead><!--  thead Begin  -->
            
            <tr><!--  tr Begin  -->

            	<th> Banck Account Details: </th>
            	<th> Carte bancaire, Back Code, Mondat Cash Details: </th>
            	<th> Virement bancaire Details: </th>


            </tr><!--  tr Finish  -->
            
        </thead><!--  thead Finish  -->
        
        <tbody><!--  tbody Begin  -->
    		<td> Banck Name: UBL | Account N°: 145-832-524 | Branch Name: Bier El Arch | Branch Code: 1598</td>
    		<td> NIC #986-124-908 | Mobile N°: +33 6 69 20 67 41 | Name: Mahieddine </td>
    		<td> Real Name: Mr HAMMOUCHE | Mobile N°: +33 6 69 20 67 41 Country: France | Name: Mahieddine | NIC #02036-521-8457 </td>
        </tbody><!--  tbody Finish  -->
        
    </table><!--  table table-bordered table-hover Finish  -->
